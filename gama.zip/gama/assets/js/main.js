

    new WOW().init();
    // plus to minus change -
    // +sign change -

    $('.fa-plus').parent('a').click(function () {
        $(this).find('i').toggleClass('fa-minus fa-plus')
    });



    window.onscroli = function () {
        myFunction()
    };
    var header = document.getElementById("myHeader");
    var sticky = header.offsetTop;

    function myFunction() {
        if (window.pageYOffset > sticky) {
            header.classList.add("sticky");
        } else {
            header.classList.remove("sticky");
        }
    }

    $(document).ready(function () {


        getLocation("/development/arcs_techonology_solutions/public");

        if (getCookie("country")) {
            $(".web-lang").html(getCookie("lang") + " | " + getCookie("country"));
        } else {
            geocookie = (decodeURIComponent(getCookie("userGeoInfo")));
            geocookie = (JSON.parse(geocookie));

            key = 'country';
            value = geocookie.countryCode;
            key1 = 'lang';
            value1 = "English";

            setCookie(key, value, 30);
            setCookie(key1, value1, 30);

            $(".web-lang").html(getCookie("lang") + " | " + getCookie("country"));
        }

    });

    $(document).init(function () {
        stopLoader();
        $(".cookiesdiv").css("display", "block");

    });


    function suscribes() {
        $(document).find(".msgerr, .msg").remove();
        if ($("#semail").val() == "") {
            $("#suscribeMe").parents(".input-group").after("<small class='msgerr col-lg-11 col-sm-12 alert alert-danger rounded-0 pl-4 py-1' style='float:left; margin-top:2px; margin-bottom:0;'> mail id required</small>");
            return false;
        }
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
        if ($("#semail").val() != "" && emailReg.test($("#semail").val())) {
            if ($("#cbx").prop("checked") == false) {
                $("#suscribeMe").parents(".input-group").after("<small class='msgerr col-lg-11 col-sm-12 alert alert-danger rounded-0 pl-4 py-1' style='float:left; margin-top:2px; margin-bottom:0;'>Please accept our GTC and Data protection policies</small>");
                return false;
            }
            $("#suscribeMe").attr("onclick", "");
            $("#suscribeMe").html("<i class='fa fa-circle-o-notch fa-spin'></i> subscribing");
            $.ajax({
                url: "subscription",
                data: {
                    email: $("#semail").val(),
                    tokenfoot: $("#tokenfoot").val()
                },
                type: 'POST',
                dataType: 'JSON',
                success: function (data) {
                    if (data["success"] == 0) {
                        $("#suscribeMe").parents(".input-group").after("<small class='msg text-white'><i class='fa fa-angle-double-right '></i>&nbsp; " + data["msg"] + "</small>");
                        for (i = 0; i < 3; i++) {
                            $(document).find(".msg").fadeOut(300);
                            $(document).find(".msg").fadeIn(300);
                        }
                        setTimeout(function () {
                            $(document).find(".msg").fadeOut(700);
                        }, 8000);
                        $("#suscribeMe").attr("onclick", "suscribes()");
                        $("#suscribeMe").html("Subscribe");
                        $("#semail").val("");
                        $("#cbx").prop("checked", false);
                    } else {
                        $("#suscribeMe").attr("onclick", "suscribes()");
                        $("#suscribeMe").parents(".input-group").after("<small class='msgerr col-lg-11 col-sm-12 alert alert-danger rounded-0 pl-4 py-1' style='float:left; margin-top:2px; margin-bottom:0;'> " + data["msg"] + " </small>");
                        return false;
                    }
                },
                error: function (data) {
                }
            });
        } else {
            $("#suscribeMe").parents(".input-group").after("<small class='msgerr col-lg-11 col-sm-12 alert alert-danger rounded-0 pl-4 py-1' style='float:left; margin-top:2px; margin-bottom:0;'> Invalid mail id</small>");
        }
    }

    grecaptcha.ready(function () {
        grecaptcha.execute('6LdV3sMUAAAAAM1v7F1dKAsfbpcVs_a-RX4ErRWf', {
            action: 'homepage'
        }).then(function (token) {
            $(document).find(".token").val(token);
        });
    });






    /* Set the width of the sidebar to 320px and the left margin of the page content to 250px */
    function toggleNav() {
        var element = document.getElementById("mySidebar");
        if (element.style.width == "320px") {
            element.style.width = "0px";
        } else {
            element.style.width = "320px";
        }
    }


    $(document)
        .ajaxStart(function () {
            startLoader();
        })
        .ajaxComplete(function () {
            stopLoader();
        })

